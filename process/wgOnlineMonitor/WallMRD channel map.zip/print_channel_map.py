#!/usr/bin/env python3

import numpy as np
import matplotlib.pyplot as plt

fig,axes = plt.subplots(figsize=(10,8))
posi_z = np.array([0, 0, 1 * 200, 1 * 200])
posi_x = np.array([30, 43, 43, 30])
PX_to_channel = [15, 11, 14, 10, 13, 9, 12, 8, 0, 1, 2, 3, 4, 5, 6, 7, 26, 23, 27, 22, 25, 21, 24, 20, 28, 19, 29, 18, 30, 17, 31, 16]

dict_PX = {}

for PXnumchip in range(3):
    if PXnumchip == 0:
        z_range = 5
        x_range = 9
        chip_name = 'chip_1'
        for PXnumchan in range(30):
            PX_name = '%s_%s' %(z_range, x_range)
            dict_PX[PX_name] = "chip = %s, chan = %s" %(PXnumchip, PX_to_channel[PXnumchan])
            x_range = x_range - 1
            if x_range == -1:
                z_range = z_range + 1
                x_range = 9
    if PXnumchip == 1:
        z_range = 3
        x_range = 9
        chip_name = 'chip_2'
        for PXnumchan in range(20):
            PX_name = '%s_%s' %(z_range, x_range)
            dict_PX[PX_name] = "chip = %s, chan = %s" %(PXnumchip, PX_to_channel[PXnumchan])
            x_range = x_range - 1
            if x_range == -1:
                z_range = z_range + 1
                x_range = 9
    if PXnumchip == 2:
        z_range = 0
        x_range = 9
        chip_name = 'chip_3'
        for PXnumchan in range(30):
            PX_name = '%s_%s' %(z_range, x_range)
            dict_PX[PX_name] = "chip = %s, chan = %s" %(PXnumchip, PX_to_channel[PXnumchan])
            x_range = x_range - 1
            if x_range == -1:
                z_range = z_range + 1
                x_range = 9

axes.set_title('WallMRD south')
# Z axis
axes.set_xlim([0, 8 * 200])
axes.set_xticks( [0, 1 * 200, 2 * 200, 3 * 200, 4 * 200, 5 * 200, 6 * 200, 7 * 200, 8 * 200] )
# X axis
axes.set_ylim([0, 450])
axes.set_yticks( [0, 30, 43, 73, 86, 116, 129, 159, 172, 202, 215, 245, 258, 288, 301, 331, 344, 374, 387, 417, 430, 460] )

axes.grid(which='major',color='black',linestyle='-')
axes.tick_params(labelbottom=False, labelleft=False, labelright=False, labeltop=False)

for z_range in range(8):
    for x_range in range(10):
        PX_name = "%s_%s" %(z_range, x_range)
        mapping = 'z = %s, x = %s\n%s' %(z_range * 200 + 100, x_range * 43 + 36.5, dict_PX[PX_name])
        axes.fill(posi_z + z_range * 200, posi_x + x_range * 43,
                  color="b", alpha=0.5)
        axes.text(z_range * 200 + 45, x_range * 43 + 45, mapping, fontsize=6)

plt.show()

axes.set_title('WallMRD south')
# Z axis
axes.set_xlim([0, 8 * 200])
axes.set_xticks( [0, 1 * 200, 2 * 200, 3 * 200, 4 * 200, 5 * 200, 6 * 200, 7 * 200, 8 * 200] )
# X axis
axes.set_ylim([0, 450])
axes.set_yticks( [0, 30, 43, 73, 86, 116, 129, 159, 172, 202, 215, 245, 258, 288, 301, 331, 344, 374, 387, 417, 430, 460] )

axes.grid(which='major',color='black',linestyle='-')
axes.tick_params(labelbottom=False, labelleft=False, labelright=False, labeltop=False)

for z_range in range(8):
    for x_range in range(10):
        PX_name = "%s_%s" %(z_range, x_range)
        mapping = 'z = %s, x = %s\n%s' %(z_range * 200 + 100, x_range * 43 + 36.5, dict_PX[PX_name])
        axes.fill(posi_z + z_range * 200, posi_x + x_range * 43,
                  color="b", alpha=0.5)
        axes.text(z_range * 200 + 45, x_range * 43 + 45, mapping, fontsize=6)

plt.show()
