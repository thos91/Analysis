#!/usr/bin/env python
# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
import numpy as np
import os
import json
from ROOT import TFile, TH1F, gDirectory, TCanvas, TF1
from ROOT import kRed, kBlue
import math




histLY_dif1 = TH1F('LY_dif1','LY_dif1', 60,0,60)
histLY_dif2 = TH1F('LY_dif2','LY_dif2', 60,0,60)
histLY_dif1.SetXTitle("Light Yield [p.e.]")
histLY_dif1.SetYTitle("number of events")
histLY_dif1.SetLineColor(kRed)
#hist_gain_dif1.SetTextColor(kRed)
histLY_dif2.SetXTitle("Light Yield [p.e.]")
histLY_dif2.SetYTitle("number of events")
histLY_dif2.SetLineColor(kBlue)
#hist_gain_dif2.SetTextColor(kBlue)

histbcid = TH1F('BCID_dif1 - BCID_dif2','BCID_dif1 - BCID_dif2', 10,-5,5)
histbcid.SetXTitle("BCID_dif1 - BCID_dif2")
histbcid.SetYTitle("number of events")
#histLY_dif1.SetLineColor(kRed)

histcos = TH1F('zenith angle','zenith angle', 100,0.0,1.0)
histcos.SetXTitle("cos")
histcos.SetYTitle("number of events")
#histcos.SetStats(0)
#histLY_dif1.SetLineColor(kRed)

histLY_sum = TH1F('LY_sum','LY_sum', 60,20,60)
histLY_sum.SetXTitle("Sum of Light Yield [p.e.]")
histLY_sum.SetYTitle("number of scintillators")
#histLY_sum.SetLineColor(kBlue)
#hist_gain_dif2.SetTextColor(kBlue)


LY = np.zeros((2, 80), dtype = np.int)
LY_count = np.zeros((2, 80), dtype = np.int)
LY_count_simul_check = np.zeros(80)
LY_count_simul = np.zeros(80)

p0 = 0.966812
p1 = 0.0105537
p2 = 5.60974e-5


final_spill_0705 = 60062

for spill in range(final_spill_0705):

    if os.path.exists('./jsonfile/spill'+str(spill)+'/spill'+str(spill)+'_dif_1.json') and os.path.exists('./jsonfile/spill'+str(spill)+'/spill'+str(spill)+'_dif_2.json'):

        print '-- spill %s --'%(spill)
        #json_input_file_name = 'spill%s_dif_%s.json'%(spill, spill, numdif)
        json_input_file_name1 = 'spill%s_dif_1.json'%(spill)
        json_input_file1 = open('./jsonfile/spill'+str(spill)+'/'+json_input_file_name1, 'r')
        json_load_file1 = json.load(json_input_file1)
        json_dumps_file1 = json.dumps(json_load_file1)
        json_file_dif1 = json.loads(json_dumps_file1)

        dif_name_dif1 = 'dif_1'
        bcid_top = json_file_dif1['BCID_dif_1']

        #json_input_file_name = 'spill%s_dif_%s.json'%(spill, spill, numdif)
        json_input_file_name2 = 'spill%s_dif_2.json'%(spill)
        json_input_file2 = open('./jsonfile/spill'+str(spill)+'/'+json_input_file_name2, 'r')
        json_load_file2 = json.load(json_input_file2)
        json_dumps_file2 = json.dumps(json_load_file2)
        json_file_dif2 = json.loads(json_dumps_file2)

        dif_name_dif2 = 'dif_2'
        bcid_bottom = json_file_dif2['BCID_dif_2']

        histbcid.Fill(bcid_top - bcid_bottom)
        #numdif = 0

        #if numdif == 0 :
            #dif_name_dif1 = 'dif_1'
            #bcid_top = json_file_dif1['BCID_dif_1']
        #elif numdif == 1:
            #dif_name_dif2 = 'dif_2'
            #bcid_bottom = json_file_dif2['BCID_dif_2']


        #dif_name_dif1 = 'dif_1'
        #bcid_top = json_file_dif1['BCID_dif_1']
        #dif_name_dif2 = 'dif_2'
        #bcid_bottom = json_file_dif2['BCID_dif_2']


        cutLY = 4.5



        fig,axes = plt.subplots(nrows=2,ncols=2,figsize=(10,8))



        posi_x = np.array([0, 0, 1 * 200, 1 * 200])
        posi_y = np.array([30, 43, 43, 30])

        #bcid_top = 100
        #bcid_bottom = 200
        time_top = 1000
        time_bottom = 2000

        #TOP SIDE
        axes[0,0].set_title('TOP SIDE')
        axes[0,0].set_xlim([0, 8 * 200])
        axes[0,0].set_xticks( [0, 1 * 200, 2 * 200, 3 * 200, 4 * 200, 5 * 200, 6 * 200, 7 * 200, 8 * 200] )
        axes[0,0].set_ylim([0, 450])
        axes[0,0].set_yticks( [0, 30, 43, 73, 86, 116, 129, 159, 172, 202, 215, 245, 258, 288, 301, 331, 344, 374, 387, 417, 430, 460] )
        axes[0,0].grid(which='major',color='black',linestyle='-')
        axes[0,0].tick_params(labelbottom=False, labelleft=False, labelright=False, labeltop=False)

        #paint hit scintillators
        y_angle_up = 5
        y_angle_down = 5
        for x_range in range(8):
            for y_range in range(10):
                PX_name = '%s_%s'%(x_range, y_range)
                if json_file_dif1[dif_name_dif1][PX_name]['LY'] > cutLY:
                    axes[0,0].fill(posi_x + x_range * 200,posi_y + y_range * 43,color="b",alpha=0.5)
                    axes[0,0].text(x_range * 200, y_range * 43, str(round(json_file_dif1[dif_name_dif1][PX_name]['LY'],1)))
                    #histLY_dif1.Fill(json_file_dif1[dif_name_dif1][PX_name]['LY'])
                    LY_int = 10 * x_range + y_range
                    LY[0][LY_int] = LY[0][LY_int] + json_file_dif1[dif_name_dif1][PX_name]['LY']
                    LY_count[0][LY_int] = LY_count[0][LY_int] + 1
		    LY_count_simul_check[LY_int] = LY_count_simul_check[LY_int] + 1

                    if y_angle_up < y_range:
                        y_angle_up = y_range
                        x_angle_up = x_range
                    if y_angle_down > y_range:
                        y_angle_down = y_range
                        x_angle_down = x_range
        dx = abs(x_angle_up - x_angle_down)
        dy = y_angle_up - y_angle_down
        if dy != 0:
            cos = dy / math.sqrt(dx * dx + dy * dy)
            if x_angle_up <= x_angle_down:
                histcos.Fill(cos)
            if x_angle_up > x_angle_down:
                histcos.Fill(cos)

        #x_range = 5
        #y_range = 9
        #axes[0,0].fill(posi_x + x_range * 200,posi_y + y_range * 43,color="b",alpha=0.5)


        #BOTTOM SIDE
        axes[0,1].set_title('BOTTOM SIDE')
        axes[0,1].set_xlim([0, 8 * 200])
        axes[0,1].set_xticks( [0, 1 * 200, 2 * 200, 3 * 200, 4 * 200, 5 * 200, 6 * 200, 7 * 200, 8 * 200] )
        axes[0,1].set_ylim([0, 450])
        axes[0,1].set_yticks( [0, 30, 43, 73, 86, 116, 129, 159, 172, 202, 215, 245, 258, 288, 301, 331, 344, 374, 387, 417, 430, 460] )
        axes[0,1].grid(which='major',color='black',linestyle='-')
        axes[0,1].tick_params(labelbottom=False, labelleft=False, labelright=False, labeltop=False)

        #paint hit scintillators
        y_angle_up = 5
        y_angle_down = 5
        for x_range in range(8):
            for y_range in range(10):
                PX_name = '%s_%s'%(x_range, y_range)
                if json_file_dif2[dif_name_dif2][PX_name]['LY'] > cutLY:
                    axes[0,1].fill(posi_x + x_range * 200,posi_y + y_range * 43,color="b",alpha=0.5)
                    axes[0,1].text(x_range * 200, y_range * 43, str(round(json_file_dif2[dif_name_dif2][PX_name]['LY'], 1)))
                    #histLY_dif2.Fill(json_file_dif2[dif_name_dif2][PX_name]['LY'])
                    LY_int = 10 * x_range + y_range
                    LY[1][LY_int] = LY[1][LY_int] + json_file_dif2[dif_name_dif2][PX_name]['LY']
                    LY_count[1][LY_int] = LY_count[1][LY_int] + 1
		    LY_count_simul_check[LY_int] = LY_count_simul_check[LY_int] + 1

                    if y_angle_up < y_range:
                        y_angle_up = y_range
                        x_angle_up = x_range
                    if y_angle_down > y_range:
                        y_angle_down = y_range
                        x_angle_down = x_range
        dx = abs(x_angle_up - x_angle_down)
        dy = y_angle_up - y_angle_down
        if dy != 0:
            cos = dy / math.sqrt(dx * dx + dy * dy)
            if x_angle_up <= x_angle_down:
                histcos.Fill(cos)
            if x_angle_up > x_angle_down:
                histcos.Fill(cos)

        



        #PLAN
        axes[1,0].set_title('PLAN')
        axes[1,0].set_xlim([-80, 80])
        axes[1,0].set_ylim([0, 1600])
        axes[1,0].set_yticks( [0, 200, 400, 600, 800, 1000, 1200, 1400, 1600] )
        for i in range(8):
            axes[1,0].plot([-80, 80], [200 * i, 200 * i], 'k-')
        axes[1,0].tick_params(labelbottom=False, labelleft=False, labelright=False, labeltop=False)
        axes[1,0].text(-80,-100, 'TOP')
        axes[1,0].text(70,-100, 'BOTTOM')

        # mark hit point
        y_point = 50

        for x_range in range(8):
            for y_range in range(10):
                PX_name = '%s_%s'%(x_range, y_range)
                y_point = (7 - x_range) * 200 + 100
                if json_file_dif1[dif_name_dif1][PX_name]['LY'] > cutLY and json_file_dif2[dif_name_dif2][PX_name]['LY'] > cutLY:

                    y = json_file_dif2[dif_name_dif2][PX_name]['LY'] / json_file_dif1[dif_name_dif1][PX_name]['LY']
                    #x1 = (-p1 + math.sqrt(p1 * p1 - 4 * p2 * (p0 - y))) / (2 * p2)
                    x = (y - p0) / p1
                    #x2 = (-p1 - math.sqrt(p1 * p1 - 4 * p2 * (p0 - y)) / (2 * p2))
                    if json_file_dif1[dif_name_dif1][PX_name]['LY'] >= json_file_dif2[dif_name_dif2][PX_name]['LY']:
                        axes[1,0].plot(x, y_point, marker='.', markersize=10)
                        axes[1,0].text(x + 5, y_point - 20, str(y_range))
                    if json_file_dif1[dif_name_dif1][PX_name]['LY'] < json_file_dif2[dif_name_dif2][PX_name]['LY']:
                        axes[1,0].plot(x, y_point, marker='.', markersize=10)
                        axes[1,0].text(x + 5, y_point - 20, str(y_range))


        #STATUS
        axes[1,1].axis('off')
        axes[1,1].set_title('Side-MRD Event Display')
        axes[1,1].text(0,0.9, 'spill = '+str(spill))
        axes[1,1].text(0,0.8, 'BCID(top) = '+str(bcid_top))
        axes[1,1].text(0,0.7, 'BCID(bottom) = '+str(bcid_bottom))
        #axes[1,1].text(0,0.6, 'time(top) = '+str(time_top))
        #axes[1,1].text(0,0.5, 'time(bottom) = '+str(time_bottom))

        #plt.show()
        #plt.pause(0.1)
        if not os.path.exists('./images/spill'+str(spill)):
            os.mkdir('./images/spill'+str(spill))
        plt.savefig('./images/spill'+str(spill)+'/eventdisplay.png')
        #plt.clf()
        plt.close()

	for x in range(8):
	    for y in range(10):
		LY_int = 10 * x + y
		if LY_count_simul_check[LY_int] == 2:
		    LY_count_simul[LY_int] = LY_count_simul[LY_int] + 1


for i in range(80):
    print 'LY [0][%s] = %s'%(i, LY[0][i] / LY_count[0][i])
    print 'LY_count[0][%s] = %s'%(i, LY_count[0][i])
    print 'LY [1][%s] = %s'%(i, LY[1][i] / LY_count[1][i])
    print 'LY_count[1][%s] = %s'%(i, LY_count[1][i])
    print 'LY[0][%s] + LY [1][%s] = %s'%(i, i, LY[0][i] / LY_count[0][i] + LY[1][i] / LY_count[1][i])
    print 'LY_count_simul[%s] = %s'%(i, LY_count_simul[i])
    histLY_dif1.Fill(LY[0][i] / LY_count[0][i])
    histLY_dif2.Fill(LY[1][i] / LY_count[1][i])
    histLY_sum.Fill(LY[0][i] / LY_count[0][i] + LY[1][i] / LY_count[1][i])

c = TCanvas()
c.Divide(2,1)
c.cd(1)
histLY_dif1.Draw()
c.cd(2)
histLY_dif2.Draw()

c.Print('./images/LY_0705_1stSMRD.png')

c = TCanvas()
histbcid.Draw()
c.Print('./images/BCID_0705_1stSMRD.png')

c = TCanvas()
histcos.Draw()
histcos.SetStats(0)

f = TF1('f', '[0] + [1] * x + [2] * x * x')
histcos.Fit('f')

c.Print('./images/zenith_angle_0705_1stSMRD_fit.png')

c = TCanvas()
histLY_sum.Draw()
c.Print('./images/LYsum_0705_1stSMRD.png')

"""
# LYs of 1stMRD 180705
LY [0][0] = 7
LY [1][0] = 23
LY [0][1] = 18
LY [1][1] = 20
LY [0][2] = 18
LY [1][2] = 20
LY [0][3] = 17
LY [1][3] = 20
LY [0][4] = 19
LY [1][4] = 20
LY [0][5] = 18
LY [1][5] = 20
LY [0][6] = 17
LY [1][6] = 20
LY [0][7] = 21
LY [1][7] = 22
LY [0][8] = 20
LY [1][8] = 21
LY [0][9] = 23
LY [1][9] = 25
LY [0][10] = 23
LY [1][10] = 23
LY [0][11] = 22
LY [1][11] = 23
LY [0][12] = 23
LY [1][12] = 23
LY [0][13] = 23
LY [1][13] = 23
LY [0][14] = 23
LY [1][14] = 23
LY [0][15] = 23
LY [1][15] = 23
LY [0][16] = 21
LY [1][16] = 24
LY [0][17] = 21
LY [1][17] = 23
LY [0][18] = 24
LY [1][18] = 26
LY [0][19] = 26
LY [1][19] = 25
LY [0][20] = 23
LY [1][20] = 23
LY [0][21] = 19
LY [1][21] = 20
LY [0][22] = 21
LY [1][22] = 23
LY [0][23] = 22
LY [1][23] = 23
LY [0][24] = 21
LY [1][24] = 24
LY [0][25] = 21
LY [1][25] = 23
LY [0][26] = 20
LY [1][26] = 21
LY [0][27] = 22
LY [1][27] = 23
LY [0][28] = 22
LY [1][28] = 21
LY [0][29] = 20
LY [1][29] = 22
LY [0][30] = 20
LY [1][30] = 22
LY [0][31] = 19
LY [1][31] = 20
LY [0][32] = 21
LY [1][32] = 22
LY [0][33] = 20
LY [1][33] = 22
LY [0][34] = 19
LY [1][34] = 21
LY [0][35] = 21
LY [1][35] = 22
LY [0][36] = 22
LY [1][36] = 23
LY [0][37] = 22
LY [1][37] = 24
LY [0][38] = 22
LY [1][38] = 22
LY [0][39] = 22
LY [1][39] = 23
LY [0][40] = 22
LY [1][40] = 22
LY [0][41] = 21
LY [1][41] = 24
LY [0][42] = 21
LY [1][42] = 22
LY [0][43] = 24
LY [1][43] = 23
LY [0][44] = 19
LY [1][44] = 21
LY [0][45] = 18
LY [1][45] = 22
LY [0][46] = 20
LY [1][46] = 22
LY [0][47] = 22
LY [1][47] = 23
LY [0][48] = 21
LY [1][48] = 23
LY [0][49] = 21
LY [1][49] = 24
LY [0][50] = 19
LY [1][50] = 21
LY [0][51] = 18
LY [1][51] = 20
LY [0][52] = 22
LY [1][52] = 23
LY [0][53] = 19
LY [1][53] = 21
LY [0][54] = 22
LY [1][54] = 22
LY [0][55] = 21
LY [1][55] = 24
LY [0][56] = 21
LY [1][56] = 21
LY [0][57] = 21
LY [1][57] = 22
LY [0][58] = 21
LY [1][58] = 22
LY [0][59] = 21
LY [1][59] = 22
LY [0][60] = 22
LY [1][60] = 21
LY [0][61] = 22
LY [1][61] = 22
LY [0][62] = 18
LY [1][62] = 20
LY [0][63] = 18
LY [1][63] = 19
LY [0][64] = 17
LY [1][64] = 21
LY [0][65] = 18
LY [1][65] = 21
LY [0][66] = 20
LY [1][66] = 22
LY [0][67] = 20
LY [1][67] = 22
LY [0][68] = 21
LY [1][68] = 23
LY [0][69] = 23
LY [1][69] = 24
LY [0][70] = 22
LY [1][70] = 23
LY [0][71] = 22
LY [1][71] = 22
LY [0][72] = 21
LY [1][72] = 21
LY [0][73] = 23
LY [1][73] = 21
LY [0][74] = 21
LY [1][74] = 21
LY [0][75] = 20
LY [1][75] = 17
LY [0][76] = 19
LY [1][76] = 18
LY [0][77] = 19
LY [1][77] = 20
LY [0][78] = 21
LY [1][78] = 19
LY [0][79] = 25
LY [1][79] = 24

# LYs of 2ndMRD 180706
LY [0][0] = 17
LY [1][0] = 24
LY [0][1] = 17
LY [1][1] = 21
LY [0][2] = 17
LY [1][2] = 20
LY [0][3] = 17
LY [1][3] = 20
LY [0][4] = 17
LY [1][4] = 19
LY [0][5] = 17
LY [1][5] = 21
LY [0][6] = 19
LY [1][6] = 24
LY [0][7] = 21
LY [1][7] = 23
LY [0][8] = 22
LY [1][8] = 25
LY [0][9] = 22
LY [1][9] = 26
LY [0][10] = 20
LY [1][10] = 24
LY [0][11] = 19
LY [1][11] = 22
LY [0][12] = 20
LY [1][12] = 24
LY [0][13] = 20
LY [1][13] = 22
LY [0][14] = 19
LY [1][14] = 24
LY [0][15] = 20
LY [1][15] = 22
LY [0][16] = 20
LY [1][16] = 24
LY [0][17] = 19
LY [1][17] = 23
LY [0][18] = 21
LY [1][18] = 25
LY [0][19] = 23
LY [1][19] = 24
LY [0][20] = 20
LY [1][20] = 21
LY [0][21] = 18
LY [1][21] = 19
LY [0][22] = 20
LY [1][22] = 20
LY [0][23] = 19
LY [1][23] = 21
LY [0][24] = 22
LY [1][24] = 24
LY [0][25] = 22
LY [1][25] = 24
LY [0][26] = 19
LY [1][26] = 20
LY [0][27] = 20
LY [1][27] = 20
LY [0][28] = 21
LY [1][28] = 24
LY [0][29] = 20
LY [1][29] = 21
LY [0][30] = 21
LY [1][30] = 22
LY [0][31] = 21
LY [1][31] = 21
LY [0][32] = 22
LY [1][32] = 23
LY [0][33] = 21
LY [1][33] = 21
LY [0][34] = 23
LY [1][34] = 21
LY [0][35] = 23
LY [1][35] = 22
LY [0][36] = 22
LY [1][36] = 20
LY [0][37] = 22
LY [1][37] = 23
LY [0][38] = 23
LY [1][38] = 22
LY [0][39] = 22
LY [1][39] = 22
LY [0][40] = 23
LY [1][40] = 23
LY [0][41] = 20
LY [1][41] = 19
LY [0][42] = 22
LY [1][42] = 21
LY [0][43] = 22
LY [1][43] = 20
LY [0][44] = 22
LY [1][44] = 22
LY [0][45] = 21
LY [1][45] = 21
LY [0][46] = 21
LY [1][46] = 21
LY [0][47] = 22
LY [1][47] = 22
LY [0][48] = 22
LY [1][48] = 21
LY [0][49] = 23
LY [1][49] = 23
LY [0][50] = 19
LY [1][50] = 21
LY [0][51] = 19
LY [1][51] = 21
LY [0][52] = 21
LY [1][52] = 25
LY [0][53] = 22
LY [1][53] = 24
LY [0][54] = 21
LY [1][54] = 25
LY [0][55] = 22
LY [1][55] = 23
LY [0][56] = 22
LY [1][56] = 25
LY [0][57] = 21
LY [1][57] = 22
LY [0][58] = 21
LY [1][58] = 24
LY [0][59] = 22
LY [1][59] = 22
LY [0][60] = 21
LY [1][60] = 23
LY [0][61] = 20
LY [1][61] = 23
LY [0][62] = 18
LY [1][62] = 23
LY [0][63] = 18
LY [1][63] = 23
LY [0][64] = 17
LY [1][64] = 26
LY [0][65] = 18
LY [1][65] = 25
LY [0][66] = 20
LY [1][66] = 27
LY [0][67] = 20
LY [1][67] = 24
LY [0][68] = 21
LY [1][68] = 27
LY [0][69] = 22
LY [1][69] = 25
LY [0][70] = 21
LY [1][70] = 25
LY [0][71] = 19
LY [1][71] = 23
LY [0][72] = 20
LY [1][72] = 24
LY [0][73] = 19
LY [1][73] = 24
LY [0][74] = 19
LY [1][74] = 23
LY [0][75] = 18
LY [1][75] = 19
LY [0][76] = 18
LY [1][76] = 23
LY [0][77] = 19
LY [1][77] = 25
LY [0][78] = 20
LY [1][78] = 23
LY [0][79] = 23
LY [1][79] = 24
"""
