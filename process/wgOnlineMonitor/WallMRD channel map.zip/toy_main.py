#!/usr/bin/env python
from ROOT import TFile, TF1, TTree, TH1F, TCanvas
#from ROOT import *
import sys
import subprocess
import json
import numpy as np
import matplotlib.pyplot as plt
import os


args = sys.argv
# ./main.py <rootfile>


numSMRD = '2nd'



for numdif in range(2):
    root_file_name = '_dif_1_1_%s_tree.root'%(numdif + 1)
    if numdif == 0:
       root_file_dif1 = TFile('./rootfile/'+args[1]+root_file_name)
       tree_file_dif1 = root_file_dif1.Get('tree')
    if numdif == 1:
       root_file_dif2 = TFile('./rootfile/'+args[1]+root_file_name)
       tree_file_dif2 = root_file_dif2.Get('tree')



histmode = TH1F('mode','mode', 8,-1,7)
histmode.SetXTitle("mode")
histmode.SetYTitle("number of events")
#histLY_sum.SetLineColor(kBlue)
#hist_gain_dif2.SetTextColor(kBlue)




# event loop
entries_dif1 = tree_file_dif1.GetEntriesFast()
entries_dif2 = tree_file_dif2.GetEntriesFast()

for jentry in xrange(entries_dif1): #jentry = spill
    # get the next tree in the chain and verify
    ientry_dif1 = tree_file_dif1.LoadTree(jentry)
    ientry_dif2 = tree_file_dif2.LoadTree(jentry)
    if ientry_dif1 < 0 or ientry_dif2 < 0:
        break

    # copy next entry into memory and verify
    nb_dif1 = tree_file_dif1.GetEntry(jentry)
    nb_dif2 = tree_file_dif2.GetEntry(jentry)
    if nb_dif1 <= 0 or nb_dif2 <= 0:
        continue

    print('entry = '+str(jentry))


    # loop over array tree element
    bcid = np.zeros((2,3,16), dtype = np.int)
    # (<dif>, <chip>, <column>)
    hit = np.zeros((2,3,36,16), dtype = np.int)
    # (<dif>, <chip>, <channel>, <column>)
    charge = np.zeros((2,3,36,16), dtype = np.int)
    # (<dif>, <chip>, <channel>, <column>)
    hit_count = np.zeros((2,3,16), dtype = np.int)
    # (<dif>, <chip>, <column>)
    time = np.zeros((2,3,36,16), dtype = np.int)
    # (<dif>, <chip>, <channel>, <column>)


    # set hit
    num_col = 0
    num_channel = 0
    num_chip = 0
    for hit_dif1 in tree_file_dif1.hit:
        hit[0][num_chip][num_channel][num_col] = hit_dif1
        if hit_dif1 == 1:
            hit_count[0][num_chip][num_col] = hit_count[0][num_chip][num_col]  + 1
        num_col = num_col + 1
        if num_col == 16:
            num_channel = num_channel + 1
            num_col = 0
            if num_channel == 36:
                num_chip = num_chip + 1
                num_channel = 0
                if num_chip == 3:
                    num_chip = 0
                    break
    for hit_dif2 in tree_file_dif2.hit:
        hit[1][num_chip][num_channel][num_col] = hit_dif2
        if hit_dif2 == 1:
            hit_count[1][num_chip][num_col] = hit_count[1][num_chip][num_col]  + 1
        num_col = num_col + 1
        if num_col == 16:
            num_channel = num_channel + 1
            num_col = 0
            if num_channel == 36:
                num_chip = num_chip + 1
                num_channel = 0
                if num_chip == 3:
                    num_chip = 0
                    break


    # set bcid
    num_col = 0
    num_chip = 0
    for bcid_dif1 in tree_file_dif1.bcid:
        bcid[0][num_chip][num_col] = bcid_dif1
        num_col = num_col + 1
        if num_col == 16:
            num_chip = num_chip + 1
            num_col = 0
            if num_chip == 3:
                num_chip = 0
                break
    for bcid_dif2 in tree_file_dif2.bcid:
        bcid[1][num_chip][num_col] = bcid_dif2
        num_col = num_col + 1
        if num_col == 16:
            num_chip = num_chip + 1
            num_col = 0
            if num_chip == 3:
                num_chip = 0
                break


    # set charge
    num_col = 0
    num_channel = 0
    num_chip = 0

    for charge_dif1 in tree_file_dif1.charge:
        if hit[0][num_chip][num_channel][num_col] == 1:
            charge[0][num_chip][num_channel][num_col] = charge_dif1
        num_col = num_col + 1
        if num_col == 16:
            num_channel = num_channel + 1
            num_col = 0
            num_event_dif1 = 0
            if num_channel == 36:
                num_chip = num_chip + 1
                num_channel = 0
                if num_chip == 3:
                    num_chip = 0
                    break
    for charge_dif2 in tree_file_dif2.charge:
        if hit[1][num_chip][num_channel][num_col] == 1:
            charge[1][num_chip][num_channel][num_col] = charge_dif2
        num_col = num_col + 1
        if num_col == 16:
            num_channel = num_channel + 1
            num_col = 0
            num_event_dif2 = 0
            if num_channel == 36:
                num_chip = num_chip + 1
                num_channel = 0
                if num_chip == 3:
                    num_chip = 0
                    break


    # set time
    num_col = 0
    num_channel = 0
    num_chip = 0

    for time_dif1 in tree_file_dif1.time:
        if hit[0][num_chip][num_channel][num_col] == 1:
            time[0][num_chip][num_channel][num_col] = time_dif1
        num_col = num_col + 1
        if num_col == 16:
            num_channel = num_channel + 1
            num_col = 0
            num_event_dif1 = 0
            if num_channel == 36:
                num_chip = num_chip + 1
                num_channel = 0
                if num_chip == 3:
                    num_chip = 0
                    break
    for time_dif2 in tree_file_dif2.time:
        if hit[1][num_chip][num_channel][num_col] == 1:
            time[1][num_chip][num_channel][num_col] = time_dif2
        num_col = num_col + 1
        if num_col == 16:
            num_channel = num_channel + 1
            num_col = 0
            num_event_dif2 = 0
            if num_channel == 36:
                num_chip = num_chip + 1
                num_channel = 0
                if num_chip == 3:
                    num_chip = 0
                    break

    eventnumber = 0

# the definition of record of event display with json

    def record_eventdisplay_json(numdif, mode, column_a, column_b, column_c, bcid):

        dict_SMRD = {'dif_1':{}, 'dif_2':{}}
        dict_PX = {}


        # input and output json file
        json_input_file_name = 'before_tuning_%sSMRD.json'%(numSMRD)
        json_input_file = open('./jsonfile/'+json_input_file_name, 'r')
        json_load_file = json.load(json_input_file)
        json_dumps_file = json.dumps(json_load_file)
        json_file = json.loads(json_dumps_file)



        PX_to_channel = [15, 11, 14, 10, 13, 9, 12, 8, 0, 1, 2, 3, 4, 5, 6, 7, 26, 23, 27, 22, 25, 21, 24, 20, 28, 19, 29, 18, 30, 17, 31, 16]
        #PX_to_chip = [2, 1, 0]


        spill = jentry
        events = eventnumber
        #bcid_dif1 = 1000
        #bcid_dif2 = 1001
        #mode = 1
        #charge_test = 1000
        #LY_test = 10.0
        #time_test = 2000
        #column = 5

        #for numdif in range(2):
        if numdif == 0:
            dict_SMRD['BCID_dif_1'] = bcid
            dif_name = 'dif_1'
        elif numdif == 1:
            dict_SMRD['BCID_dif_2'] = bcid
            dif_name = 'dif_2'

        for PXnumchip in range(3):
            if PXnumchip == 0:
                x_range = 5
                y_range = 9
                chip_name = 'chip_1'
                for PXnumchan in range(30):
                    PX_name = '%s_%s'%(x_range, y_range)
                    channel_name = 'channel_%s'%(PX_to_channel[PXnumchan] + 1)
                    dict_PX[PX_name] = {}
                    if mode == 0 or mode == 1 or mode == 4:
                        column = column_a
                        #dict_PX[PX_name]['charge'] = charge_test
                        dict_PX[PX_name]['charge'] = charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]
                        #dict_PX[PX_name]['LY'] = LY_test
                        dict_PX[PX_name]['LY'] = (charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column] - json_file[dif_name][chip_name][channel_name]['ped']) / json_file[dif_name][chip_name][channel_name]['gain_1pe']
                        #dict_PX[PX_name]['time'] = time_test
                        dict_PX[PX_name]['time'] = time[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]

                    elif mode == 3:
                        column = column_b
                        #dict_PX[PX_name]['charge'] = charge_test
                        dict_PX[PX_name]['charge'] = charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]
                        #dict_PX[PX_name]['LY'] = LY_test
                        dict_PX[PX_name]['LY'] = (charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column] - json_file[dif_name][chip_name][channel_name]['ped']) / json_file[dif_name][chip_name][channel_name]['gain_1pe']
                        #dict_PX[PX_name]['time'] = time_test
                        dict_PX[PX_name]['time'] = time[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]

                    else :
                        dict_PX[PX_name]['charge'] = 0
                        #dict_PX[PX_name]['charge'] = charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]
                        dict_PX[PX_name]['LY'] = 0
                        #dict_PX[PX_name]['LY'] = (charge[nunmdif][PXnumchip][PX_to_channel[PXnumchan]][column] - json_file[dif_name][chip_name][channel_name]['ped']) / json_file[dif_name][chip_name][channel_name]['gain_1pe']
                        dict_PX[PX_name]['time'] = 0
                        #dict_PX[PX_name]['time'] = time[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]


                    y_range = y_range - 1
                    if y_range == -1:
                        x_range = x_range + 1
                        y_range = 9

                        
                for NotConnectChan in range(31, 33):
                    if numdif == 0:
                        NotConnectChanName = 'chip3_PX%s'%(NotConnectChan)
                    elif numdif == 1:
                        NotConnectChanName = 'chip6_PX%s'%(NotConnectChan)
                    dict_PX[NotConnectChanName] = {}
                    if mode == 0 or mode == 1 or mode == 4:
                        column = column_a
                        dict_PX[NotConnectChanName]['charge'] = charge[numdif][PXnumchip][PX_to_channel[NotConnectChan - 1]][column]
                        dict_PX[NotConnectChanName]['time'] = time[numdif][PXnumchip][PX_to_channel[NotConnectChan - 1]][column]
                    elif mode == 3:
                        column = column_b
                        dict_PX[NotConnectChanName]['charge'] = charge[numdif][PXnumchip][PX_to_channel[NotConnectChan - 1]][column]
                        dict_PX[NotConnectChanName]['time'] = time[numdif][PXnumchip][PX_to_channel[NotConnectChan - 1]][column]
                    else:
                        dict_PX[NotConnectChanName]['charge'] = 0
                        dict_PX[NotConnectChanName]['time'] = 0
                        
        
        

            if PXnumchip == 1:
                x_range = 3
                y_range = 9
                chip_name = 'chip_2'
                for PXnumchan in range(20):
                    channel_name = 'channel_%s'%(PX_to_channel[PXnumchan] + 1)
                    PX_name = '%s_%s'%(x_range, y_range)
                    dict_PX[PX_name] = {}
                    if mode == 0 or mode == 1:
                        column = column_b
                        #dict_PX[PX_name]['charge'] = charge_test
                        dict_PX[PX_name]['charge'] = charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]
                        #dict_PX[PX_name]['LY'] = LY_test
                        dict_PX[PX_name]['LY'] = (charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column] - json_file[dif_name][chip_name][channel_name]['ped']) / json_file[dif_name][chip_name][channel_name]['gain_1pe']
                        #dict_PX[PX_name]['time'] = time_test
                        dict_PX[PX_name]['time'] = time[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]

                    elif mode == 2 or mode == 5:
                        column = column_a
                        #dict_PX[PX_name]['charge'] = charge_test
                        dict_PX[PX_name]['charge'] = charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]
                        #dict_PX[PX_name]['LY'] = LY_test
                        dict_PX[PX_name]['LY'] = (charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column] - json_file[dif_name][chip_name][channel_name]['ped']) / json_file[dif_name][chip_name][channel_name]['gain_1pe']
                        #dict_PX[PX_name]['time'] = time_test
                        dict_PX[PX_name]['time'] = time[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]

                    else :
                        dict_PX[PX_name]['charge'] = 0
                        #dict_PX[PX_name]['charge'] = charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]
                        dict_PX[PX_name]['LY'] = 0
                        #dict_PX[PX_name]['LY'] = (charge[nunmdif][PXnumchip][PX_to_channel[PXnumchan]][column] - json_file[dif_name][chip_name][channel_name]['ped']) / json_file[dif_name][chip_name][channel_name]['gain_1pe']
                        dict_PX[PX_name]['time'] = 0
                        #dict_PX[PX_name]['time'] = time[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]

                    y_range = y_range - 1
                    if y_range == -1:
                        x_range = x_range + 1
                        y_range = 9


                for NotConnectChan in range(21, 33):
                    if numdif == 0:
                        NotConnectChanName = 'chip2_PX%s'%(NotConnectChan)
                    elif numdif == 1:
                        NotConnectChanName = 'chip5_PX%s'%(NotConnectChan)
                    dict_PX[NotConnectChanName] = {}
                    if mode == 0 or mode == 1:
                        column = column_b
                        dict_PX[NotConnectChanName]['charge'] = charge[numdif][PXnumchip][PX_to_channel[NotConnectChan - 1]][column]
                        dict_PX[NotConnectChanName]['time'] = time[numdif][PXnumchip][PX_to_channel[NotConnectChan - 1]][column]
                    elif mode == 2 or mode == 5:
                        column = column_a
                        dict_PX[NotConnectChanName]['charge'] = charge[numdif][PXnumchip][PX_to_channel[NotConnectChan - 1]][column]
                        dict_PX[NotConnectChanName]['time'] = time[numdif][PXnumchip][PX_to_channel[NotConnectChan - 1]][column]
                    else:
                        dict_PX[NotConnectChanName]['charge'] = 0
                        dict_PX[NotConnectChanName]['time'] = 0


            if PXnumchip == 2:
                x_range = 0
                y_range = 9
                chip_name = 'chip_3'
                for PXnumchan in range(30):
                    channel_name = 'channel_%s'%(PX_to_channel[PXnumchan] + 1)
                    PX_name = '%s_%s'%(x_range, y_range)
                    dict_PX[PX_name] = {}
                    if mode == 0:
                        column = column_c
                        #dict_PX[PX_name]['charge'] = charge_test
                        dict_PX[PX_name]['charge'] = charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]
                        #dict_PX[PX_name]['LY'] = LY_test
                        dict_PX[PX_name]['LY'] = (charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column] - json_file[dif_name][chip_name][channel_name]['ped']) / json_file[dif_name][chip_name][channel_name]['gain_1pe']
                        #dict_PX[PX_name]['time'] = time_test
                        dict_PX[PX_name]['time'] = time[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]

                    elif mode == 2:
                        column = column_b
                        #dict_PX[PX_name]['charge'] = charge_test
                        dict_PX[PX_name]['charge'] = charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]
                        #dict_PX[PX_name]['LY'] = LY_test
                        dict_PX[PX_name]['LY'] = (charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column] - json_file[dif_name][chip_name][channel_name]['ped']) / json_file[dif_name][chip_name][channel_name]['gain_1pe']
                        #dict_PX[PX_name]['time'] = time_test
                        dict_PX[PX_name]['time'] = time[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]

                    elif mode == 3 or mode == 6:
                        column = column_a
                        #dict_PX[PX_name]['charge'] = charge_test
                        dict_PX[PX_name]['charge'] = charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]
                        #dict_PX[PX_name]['LY'] = LY_test
                        dict_PX[PX_name]['LY'] = (charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column] - json_file[dif_name][chip_name][channel_name]['ped']) / json_file[dif_name][chip_name][channel_name]['gain_1pe']
                        #dict_PX[PX_name]['time'] = time_test
                        dict_PX[PX_name]['time'] = time[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]

                    else :
                        dict_PX[PX_name]['charge'] = 0
                        #dict_PX[PX_name]['charge'] = charge[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]
                        dict_PX[PX_name]['LY'] = 0
                        #dict_PX[PX_name]['LY'] = (charge[nunmdif][PXnumchip][PX_to_channel[PXnumchan]][column] - json_file[dif_name][chip_name][channel_name]['ped']) / json_file[dif_name][chip_name][channel_name]['gain_1pe']
                        dict_PX[PX_name]['time'] = 0
                        #dict_PX[PX_name]['time'] = time[numdif][PXnumchip][PX_to_channel[PXnumchan]][column]

                    y_range = y_range - 1
                    if y_range == -1:
                        x_range = x_range + 1
                        y_range = 9
                                                                       
                                                                       
                for NotConnectChan in range(31, 33):
                   if numdif == 0:
                        NotConnectChanName = 'chip1_PX%s'%(NotConnectChan)
                   elif numdif == 1:
                        NotConnectChanName = 'chip4_PX%s'%(NotConnectChan)
                   dict_PX[NotConnectChanName] = {}
                   if mode == 0:
                       column = column_c
                       dict_PX[NotConnectChanName]['charge'] = charge[numdif][PXnumchip][PX_to_channel[NotConnectChan - 1]][column]
                       dict_PX[NotConnectChanName]['time'] = time[numdif][PXnumchip][PX_to_channel[NotConnectChan - 1]][column]
                   elif mode == 2:
                        column = column_b
                        dict_PX[NotConnectChanName]['charge'] = charge[numdif][PXnumchip][PX_to_channel[NotConnectChan - 1]][column]
                        dict_PX[NotConnectChanName]['time'] = time[numdif][PXnumchip][PX_to_channel[NotConnectChan - 1]][column]
                   elif mode == 3 or mode == 6:
                        column = column_a
                        dict_PX[NotConnectChanName]['charge'] = charge[numdif][PXnumchip][PX_to_channel[NotConnectChan - 1]][column]
                        dict_PX[NotConnectChanName]['time'] = time[numdif][PXnumchip][PX_to_channel[NotConnectChan - 1]][column]
                   else:
                        dict_PX[NotConnectChanName]['charge'] = 0
                        dict_PX[NotConnectChanName]['time'] = 0

    
    
        if numdif == 0:
            dict_SMRD['dif_1'] = dict_PX
        elif numdif == 1:
            dict_SMRD['dif_2'] = dict_PX


        if not os.path.exists('./jsonfile/spill'+str(spill)):
            os.mkdir('./jsonfile/spill'+str(spill))
        outputjson = open('./jsonfile/spill'+str(spill)+'/spill'+str(spill)+'_dif_'+str(numdif + 1)+'_'+str(events)+'.json' , 'w')
        json.dump(dict_SMRD,outputjson,indent=4)
        #print(dict_SMRD)
        
        histmode.Fill(mode)

















    hit_num = 3



    # set columns of cosmic event
    event_column = np.zeros((16,16,16), dtype = np.int)

    #Event display on Top side
    count = 0
    count_allchips = 0
    for col_a in range(16):
        for col_b in range(16):
            if bcid[0][0][col_a] == bcid[0][1][col_b] and hit_count[0][0][col_a] + hit_count[0][1][col_b] > hit_num:
                for col_c in range(16):
                    if bcid[0][1][col_b] == bcid[0][2][col_c]:
                        #event display chip1 and chip2 and chip3
                        print '---- dif_1 mode 0 ----'
                        print 'chip1 bcid = %s, chip2 bcid = %s, chip3 bcid = %s'%(bcid[0][0][col_a], bcid[0][1][col_b], bcid[0][2][col_c])
                        record_eventdisplay_json(0, 0, col_a, col_b, col_c, bcid[0][0][col_a])
                        eventnumber += 1
                        #record_eventdisplay_json(0, col_a, col_b, col_c)
                        count = 1
                        count_allchips = 1
                if count == 0:
                    #event display chip1 and chip2
                    print '---- dif_1 mode 1 ----'
                    print 'chip1 bcid = %s, chip2 bcid = %s'%(bcid[0][0][col_a], bcid[0][1][col_b])
                    record_eventdisplay_json(0, 1, col_a, col_b, 0, bcid[0][0][col_a])
                    #record_eventdisplay_json(1, col_a, col_b, 0)
                    eventnumber += 1

    count = 0
    for col_a in range(16):
        for col_b in range(16):
            if bcid[0][1][col_a] == bcid[0][2][col_b] and hit_count[0][1][col_a] + hit_count[0][2][col_b] > hit_num:
                for col_c in range(16):
                    if bcid[0][2][col_b] == bcid[0][0][col_c] and count_allchips == 0:
                        #event display chip2 and chip3 and chip1
                        print '---- dif_1 mode 0 ----'
                        record_eventdisplay_json(0, 0, col_a, col_b, col_c, bcid[0][2][col_b])
                        eventnumber += 1
                        #record_eventdisplay_json(0, col_a, col_b, col_c)
                        count = 1
                if count == 0:
                    #event display chip2 and chip3
                    print '---- dif_1 mode 2 ----'
                    print 'chip2 bcid = %s, chip3 bcid = %s'%(bcid[0][1][col_a], bcid[0][2][col_b])
                    record_eventdisplay_json(0, 2, col_a, col_b, 0, bcid[0][1][col_a])
                    eventnumber += 1
                    #record_eventdisplay_json(2, col_a, col_b, 0)

    count = 0
    for col_a in range(16):
        for col_b in range(16):
            if bcid[0][2][col_a] == bcid[0][0][col_b] and hit_count[0][2][col_a] + hit_count[0][0][col_b] > hit_num:
                for col_c in range(16):
                    if bcid[0][0][col_b] == bcid[0][1][col_c] and count_allchips == 0:
                        #event display chip3 and chip1 and chip2
                        print '---- dif_1 mode 0 ----'
                        record_eventdisplay_json(0, 0, col_a, col_b, col_c, bcid[0][0][col_b])
                        eventnumber += 1
                        #record_eventdisplay_json(0, col_a, col_b, col_c)
                        count = 1
                if count == 0:
                    #event display chip3 and chip1
                    print '---- dif_1 mode 3 ----'
                    print 'chip3 bcid = %s, chip1 bcid = %s'%(bcid[0][2][col_a], bcid[0][0][col_b])
                    record_eventdisplay_json(0, 3, col_a, col_b, 0, bcid[0][2][col_a])
                    eventnumber += 1
                    #record_eventdisplay_json(3, col_a, col_b, 0)



    count = 0
    for col_a in range(16):
        for col_b in range(16):
            for col_c in range(16):
                if bcid[0][0][col_a] == bcid[0][1][col_b] or bcid[0][1][col_b] == bcid[0][2][col_c]:
                    if hit_count[0][0][col_a] + hit_count[0][1][col_b] + hit_count[0][2][col_c] > 10:
                        count = 1
    if count == 0:
        for col_a in range(16):
            if hit_count[0][0][col_a] > hit_num - 2:
                #event display chip1
                print '---- dif_1 mode 4 ----'
                print 'chip1 bcid = %s'%(bcid[0][0][col_a])
                record_eventdisplay_json(0, 4, col_a, 0, 0, bcid[0][0][col_a])
                eventnumber += 1
                #record_eventdisplay_json(4, col_a, 0, 0)
            if hit_count[0][1][col_a] > hit_num - 2:
                #event display chip2
                print '---- dif_1 mode 5 ----'
                print 'chip2 bcid = %s'%(bcid[0][1][col_a])
                record_eventdisplay_json(0, 5, col_a, 0, 0, bcid[0][1][col_a])
                eventnumber += 1
                #record_eventdisplay_json(5, col_a, 0, 0)
            if hit_count[0][2][col_a] > hit_num - 2:
                #event display chip3
                print '---- dif_1 mode 6 ----'
                print 'chip3 bcid = %s'%(bcid[0][2][col_a])
                record_eventdisplay_json(0, 6, col_a, 0, 0, bcid[0][2][col_a])
                eventnumber += 1
                #record_eventdisplay_json(6, col_a, 0, 0)


    #Event display on Bottom side
    count = 0
    count_allchips = 0
    for col_a in range(16):
        for col_b in range(16):
            if bcid[1][0][col_a] == bcid[1][1][col_b] and hit_count[1][0][col_a] + hit_count[1][1][col_b] > hit_num:
                for col_c in range(16):
                    if bcid[1][1][col_b] == bcid[1][2][col_c]:
                        #event display chip1 and chip2 and chip3
                        print '---- dif_2 mode 0 ----'
                        print 'chip1 bcid = %s, chip2 bcid = %s, chip3 bcid = %s'%(bcid[1][0][col_a], bcid[1][1][col_b], bcid[1][2][col_c])
                        record_eventdisplay_json(1, 0, col_a, col_b, col_c, bcid[1][0][col_a])
                        eventnumber += 1
                        #record_eventdisplay_json(0, col_a, col_b, col_c)
                        count = 1
                        count_allchips = 1
                if count == 0:
                    #event display chip1 and chip2
                    print '---- dif_2 mode 1 ----'
                    print 'chip1 bcid = %s, chip2 bcid = %s'%(bcid[1][0][col_a], bcid[1][1][col_b])
                    record_eventdisplay_json(1, 1, col_a, col_b, 0, bcid[1][0][col_a])
                    eventnumber += 1
                    #record_eventdisplay_json(1, col_a, col_b, 0)

    count = 0
    for col_a in range(16):
        for col_b in range(16):
            if bcid[1][1][col_a] == bcid[1][2][col_b] and hit_count[1][1][col_a] + hit_count[1][2][col_b] > hit_num:
                for col_c in range(16):
                    if bcid[1][2][col_b] == bcid[1][0][col_c] and count_allchips == 0:
                        #event display chip2 and chip3 and chip1
                        print '---- dif_2 mode 0 ----'
                        record_eventdisplay_json(1, 0, col_a, col_b, col_c, bcid[1][2][col_b])
                        eventnumber += 1
                        #record_eventdisplay_json(0, col_a, col_b, col_c)
                        count = 1
                if count == 0:
                    #event display chip2 and chip3
                    print '---- dif_2 mode 2 ----'
                    print 'chip2 bcid = %s, chip3 bcid = %s'%(bcid[1][1][col_a], bcid[1][2][col_b])
                    record_eventdisplay_json(1, 2, col_a, col_b, 0, bcid[1][1][col_a])
                    eventnumber += 1
                    #record_eventdisplay_json(2, col_a, col_b, col_c)

    count = 0
    for col_a in range(16):
        for col_b in range(16):
            if bcid[1][2][col_a] == bcid[1][0][col_b] and hit_count[1][2][col_a] + hit_count[1][0][col_b] > hit_num:
                for col_c in range(16):
                    if bcid[1][0][col_b] == bcid[1][1][col_c] and count_allchips == 0:
                        #event display chip3 and chip1 and chip2
                        print '---- dif_2 mode 0 ----'
                        record_eventdisplay_json(1, 0, col_a, col_b, col_c, bcid[1][0][col_b])
                        eventnumber += 1
                        #record_eventdisplay_json(0, col_a, col_b, col_c)
                        count = 1
                if count == 0:
                    #event display chip3 and chip1
                    print '---- dif_2 mode 3 ----'
                    print 'chip3 bcid = %s, chip1 bcid = %s'%(bcid[1][2][col_a], bcid[1][0][col_b])
                    record_eventdisplay_json(1, 3, col_a, col_b, 0, bcid[1][2][col_a])
                    eventnumber += 1
                    #record_eventdisplay_json(3, col_a, col_b, col_c)



    count = 0
    for col_a in range(16):
        for col_b in range(16):
            for col_c in range(16):
                if bcid[1][0][col_a] == bcid[1][1][col_b] or bcid[1][1][col_b] == bcid[1][2][col_c]:
                    if hit_count[1][0][col_a] + hit_count[1][1][col_b] + hit_count[1][2][col_c] > 10:
                        count = 1
    if count == 0:
        for col_a in range(16):
            if hit_count[1][0][col_a] > hit_num - 2:
                #event display chip1
                print '---- dif_2 mode 4 ----'
                print 'chip1 bcid = %s'%(bcid[1][0][col_a])
                record_eventdisplay_json(1, 4, col_a, 0, 0, bcid[1][0][col_a])
                eventnumber += 1
                #record_eventdisplay_json(4, col_a, col_b, col_c)
            if hit_count[1][1][col_a] > hit_num - 2:
                #event display chip2
                print '---- dif_2 mode 5 ----'
                print 'chip2 bcid = %s'%(bcid[1][1][col_a])
                record_eventdisplay_json(1, 5, col_a, 0, 0, bcid[1][1][col_a])
                eventnumber += 1
                #record_eventdisplay_json(5, col_a, col_b, col_c)
            if hit_count[1][2][col_a] > hit_num - 2:
                #event display chip3
                print '---- dif_2 mode 6 ----'
                print 'chip3 bcid = %s'%(bcid[1][2][col_a])
                record_eventdisplay_json(1, 6, col_a, 0, 0, bcid[1][2][col_a])
                eventnumber += 1
                #record_eventdisplay_json(6, col_a, col_b, col_c)


c = TCanvas()
fout = TFile("mode_"+numSMRD+"SMRD.root", "recreate")
histmode.Write()
fout.Close()
